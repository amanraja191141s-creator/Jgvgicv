# All-tools UI audit — v98.68

| Tool | Screen ID | Shared reference UI | Tool-specific controls retained |
|---|---|---|---|
| GST Calculator | salestax | Yes | GST mode, state mode, 5%/18%, CGST/SGST/IGST |
| Loan / EMI | loan | Yes | Amount, interest, tenure units, EMI results |
| Saving | savings | Yes | Deposit, monthly contribution, frequency, rate, tax |
| Salary | salary | Yes | Gross salary, deductions, monthly/annual take-home |
| Tip | tip | Yes | Bill, tip rate, people, per-person/total results |
| SIP | sip | Yes | SIP and delay-cost tabs, investment fields, projections |
| Currency Converter | currencies | Yes | Currency selectors, swap, refresh, rate status/time |
| Discount | discount | Yes | Original price, discount, savings, final price |
| Percentage | percent | Yes | Percentage and percent-change modes |
| Unit Converter | units | Yes | 12 categories, unit selectors, swap, conversion |
| Age | agecalc | Yes | DOB, today date, age result |
| BMI | bodymetrics | Yes | kg/lbs, cm/in, BMI result |

## Layout contract
- Every listed tool has one scrollable content plane above the shared keypad.
- Keypad is a single app-container-anchored dock, 4 columns × 4 rows, with the equals key spanning rows 3–4.
- Tall phone keypad height is `min(40dvh, 620px)`; short and landscape fallbacks are separately defined.
- Input values and result values wrap within available width; cards are full-width within consistent screen gutters.
- The unit chooser is horizontal and scrollable; hidden workspaces remain hidden.
- The canonical tool stylesheet uses existing theme tokens and coral action accent.

This is a source-level layout audit. Exact physical-device rendering, touch latency, sustained frame rate, memory behavior, APK installation and live currency provider availability remain device/CI checks.
