# SA Calculator v98.65

This release replaces the previous tool-screen look with the supplied Android screenshot-reference UI.

## Build and test
```bash
npm run build:web
npm run test:release
```

Android debug APK build is performed by the workflow at `.github/workflows/main.yml`.

## Release
- Version: `1.98.79-v98.65`
- Android version code: `1098086`
- Tools covered: GST, Loan, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age and BMI.

See `SCREENSHOT-UI-REPLACEMENT-AUDIT-v98.65.md` and `RELEASE-VERIFICATION-v98.65.md` for scope and verification boundaries.
