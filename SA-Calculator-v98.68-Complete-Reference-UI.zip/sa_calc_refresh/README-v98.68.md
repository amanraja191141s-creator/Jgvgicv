# SA Calculator v98.68 — Clean reference UI rebuild

- App version: `1.98.82-v98.68`
- Android versionCode: `1098089`
- UI: one canonical responsive screenshot-reference layer for all 12 calculator tools
- Keypad: one app-anchored 4-column dock; input/result workspace scrolls above it
- Theme: uses the existing app theme surface/text tokens with coral tool actions
- Workflow: `Android-Workflow-v98.68.yml`

Copy `Android-Workflow-v98.68.yml` to `.github/workflows/main.yml`, commit the complete project root, push to `main`, then run Android workflow from GitHub Actions.
