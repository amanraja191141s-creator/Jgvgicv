# Video-reference micro-level audit — v98.63.9.26

## Inputs reviewed
- `Screenrecording_20261121_182428.mp4` — scientific keypad reference.
- `Screenrecording_20261121_182622.mp4` — Other Calculator tools catalogue reference.
- Base source: v98.63.9.25 ZIP and Android workflow YAML.

## Scientific panel changes
- Main 4×4 matrix now presents the recorded function family order: INV + inverse trig; hyperbolic + i; inverse hyperbolic + cube root; 2ˣ, x³, x⁻ʸ and plus.
- Functions are flat/unboxed text keys on a pink surface. Drawer now fills the keypad band width; no separate display/toolbar is shown inside the scientific panel.
- The plus toggle opens a second 4×4 matrix with the previously available basic scientific functions. Escape closes that layer before the scientific drawer.
- INV swaps inverse/normal trig and hyperbolic labels/tokens one-shot.
- Parser adds `asinh`, `acosh`, and `atanh` with domain/range finite checks.
- Cube button uses a selection-aware action (`selected expression → (expression)^3`) instead of blindly appending a token.
- The imaginary-unit key is present but complex-number evaluation is not supported; the app shows a clear message instead of a misleading result.

## Tools catalogue changes
- Three-column pale-blue rounded tile style, icons, readable centered names, group headers.
- Finance order includes GST/VAT, Loan, Saving, Salary, Tip, SIP, Currency, Discount and Unit Price.
- Math/General Utilities and Health groups are arranged to match the clip.
- Existing extra tools are preserved. Age and BMI are separate tiles; BMI opens the existing Body Metrics calculator.
- Added Salary and SIP calculations and an Age calculator destination.

## Verification
- `npm test`: 60 focused tests pass.
- `npm run build:web`: 13 required assets prepared.
- Workflow YAML parse: pass.
- ZIP extraction/integrity: pass.
- APK build and physical-device touch/visual performance: not verified here.
