# Independent QA results — v98.63.9.36

| Check | Result |
|---|---|
| JavaScript syntax (`assets/js/app.js`) | PASS |
| Android web bundle (`npm run build:web`) | PASS — 13 assets |
| Focused release tests (`npm run test:release`) | PASS — 59/59 |
| Workflow mirror integrity | PASS — three copies byte-identical |
| ZIP extraction integrity | PASS |
| README release identity | Corrected to v98.63.9.36 |
| Historical suite (`npm run test:legacy`) | DIAGNOSTIC ONLY — 387/516 pass; 129 stale/legacy failures |
| npm dependency install | Not completed within execution window |
| Browser/device visual test | Not run |
| Android Gradle/APK build | Not run |

The focused release suite is the configured release gate. Historical failures are retained and documented; they are not part of the current release command.
