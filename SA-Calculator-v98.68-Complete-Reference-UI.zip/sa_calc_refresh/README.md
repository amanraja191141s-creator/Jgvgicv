# SA Calculator v98.68 — Clean Reference UI Rebuild

SA Calculator is a mobile-first calculator app with standard/scientific calculation, history, favorites, themes, localization, and 12 calculator tools.

## Release identity
- App version: `1.98.82-v98.68`
- Android versionCode: `1098089`
- Current tool UI stylesheet: `assets/css/tool-reference-ui.css`
- Android workflow: `Android-Workflow-v98.68.yml`

## Included tool screens
GST, Loan/EMI, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age and BMI.

## Verify locally
```sh
npm test
npm run build:web
```

## Android APK
Copy `Android-Workflow-v98.68.yml` to `.github/workflows/main.yml`, commit the complete project, and run the workflow in GitHub Actions. It generates/synchronizes the Capacitor Android project and assembles a debug APK. The source archive does not include a generated Android Gradle project or prebuilt APK.

## Validation boundary
The v98.68 release passed 71 automated regression tests, JavaScript syntax checks, YAML parsing, duplicate-ID checks, and Android web-bundle synchronization. APK compilation, installation, physical-device layout, frame rate, memory pressure and live currency API behavior still require GitHub Actions and target-device testing. Automated tests do not prove zero lag or zero bugs on every Android device.
