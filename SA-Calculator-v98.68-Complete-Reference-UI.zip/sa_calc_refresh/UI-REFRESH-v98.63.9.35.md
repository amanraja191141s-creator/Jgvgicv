# SA Calculator — All Tools UI Refresh

## Scope
Applied a presentation-only finish layer to the existing SA Calculator v98.63.9.35 source. Existing screen IDs, tool routes, calculation functions, event targets, and data attributes were preserved.

## Source inventory verified
- 19 dashboard tool cards, each mapped to an existing screen:
  `salestax`, `loan`, `savings`, `salary`, `tip`, `sip`, `currencies`, `discount`, `unitprice`, `percent`, `units`, `hex`, `gradeavg`, `fuelefficiency`, `agecalc`, `bodymetrics`, `date`, `fuelcost`, `worldtime`.
- 12 Unit Converter categories.
- Main calculator and Scientific mode remain separate from the 19 dashboard tools.

## UI changes
- Added a unified design token layer for light and dark themes.
- Standardized tool canvas, scroll area, content width, card surfaces, borders, radii, spacing and shadows.
- Standardized editable numeric fields, active/focus state, value sizing and unit selectors.
- Standardized result hierarchy, label/value contrast, numeric alignment and wrapping.
- Standardized primary actions, tabs and percentage/tip presets.
- Refined the Other Calculator dashboard into a responsive grouped 3/4/5-column tile grid.
- Refined Unit Converter category tiles and source/destination field composition.
- Refined currency pair layout, swap control and exchange-rate status area.
- Added tool-specific layout finishing for Loan, SIP, Savings, Salary, GST/VAT, Grade Average, HEX, Age, BMI, Date, Fuel Cost, Fuel Efficiency, Unit Price, Tip, Discount, Percentage and World Time.
- Added compact-width, medium-width, expanded-width and compact-height rules.
- Added reduced-motion handling and kept ad containers in normal document flow.
- Did not change calculation logic or invent new calculator features.

## Verification performed
- `node --check assets/js/app.js`: PASS.
- `npm run build:web`: PASS; 13 required web assets verified and canonical stylesheet copied.
- `npm run test:release`: PASS; 57 tests, 0 failures.
- CSS parsed with tinycss2: 4,832 rules, 0 parse errors.
- Source and `www/` stylesheet parity: PASS.
- Source and `www/` HTML parity: PASS.
- Tool-card inventory: 19; all 19 have corresponding `screen-*` targets.
- Unit Converter category count: 12.
- Workflow YAML parsed successfully; standalone YAML and `.github/workflows/main.yml` SHA-256 match.
- ZIP integrity checked after packaging.

## Limitations
- Browser-based visual screenshot and physical Android/WebView interaction tests were not run in this environment. Therefore pixel-perfect rendering, device-specific font metrics, touch response, and runtime ad layout are not certified.
- The workflow YAML is unchanged because this is a CSS/UI-only patch and the existing release identity remains v98.63.9.35.
- Existing calculation behavior is preserved; this refresh does not certify every formula beyond the pre-existing automated release tests.
