# SA Calculator v98.63.9.28 — Scientific keypad reference correction

- Reworked the main scientific function matrix to the supplied reference's exact 4×4 order: INV, sin/cos/tan, ln/log/absolute/factorial, pi/e/e^x/sqrt, 10^x/x²/x^y/More.
- INV is a one-shot modifier for sine/cosine/tangent only, switching them to asin/acos/atan.
- Moved hyperbolic/inverse-hyperbolic, cube root, 2^x, cube, negative power, log2 and complex-unit entry to the secondary More matrix.
- Reworked the panel background to pink, primary keys to unboxed dark labels, INV to a circular toggle, and More to a dark circular plus control.
- Maintained the existing expression display, parsing/evaluation, touch opening/closing, history and accessibility behavior.
- Updated Android/PWA release identity to 1.98.75-v98.63.9.28 (versionCode 1098076).
