# SA Calculator v98.65 — Screenshot UI replacement

- Replaced the previous v98.64 appended screenshot CSS layer with one dedicated canonical `assets/css/tool-reference-ui.css` stylesheet.
- Applied the supplied coral/light screenshot system consistently to all 12 requested tools.
- Preserved existing calculation element IDs, keypad event wiring and tool logic.
- Standardized white rounded cards, labels, inputs, active controls, result cards and the four-column shared keypad.
- Retained BMI kg/lbs and cm/in controls, Age date input, horizontal Unit categories and distinct Currency selectors/rate note.
- Added the new stylesheet to Android web bundle preflight and byte-for-byte bundle verification.
- Updated release identity to `1.98.79-v98.65` and Android version code `1098086`.
- Corrected workflow preflight to use actual committed test filenames.
