# v98.63.9.33 — Single docked Tools keypad

- Removed embedded legacy numeric keypad blocks from currency, unit, discount and percent tool screens.
- Removed the old modal overlay, title and value-preview chrome; one shared docked keypad is the only numeric tool keypad.
- Numeric tool screens now focus their first visible editable field and open the docked keypad on entry.
- Calculate/equals recalculates and scrolls results into the visible area above the keypad without dismissing it.
- Kept the main calculator keypad and dedicated hexadecimal keypad independent.
- Rebuilt the Android workflow source checks against actual current project files and added explicit Android SDK provisioning.
