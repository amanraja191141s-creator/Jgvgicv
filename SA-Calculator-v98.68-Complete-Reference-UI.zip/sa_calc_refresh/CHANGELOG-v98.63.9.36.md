# v98.63.9.36 — Video-matched tool UI and behavior rebuild

- Replaced the legacy Loan Calculator screen with the recorded amount / rate / tenure flow, Months / Years selector, validation and EMI result summary.
- Added SIP Delay Cost comparison mode with a strict 12-month delay limit.
- Rebuilt Tip Calculator around Bill Amount, Rate of Tip and Number of Person; removed the obsolete presets and hidden tax controls.
- Simplified Unit Converter detail flow to live conversion and fixed long-result clipping.
- Bumped release identity and Android version code; synchronized the standalone workflow and GitHub Actions workflow.
- Added focused regression checks for the new tool flows.
