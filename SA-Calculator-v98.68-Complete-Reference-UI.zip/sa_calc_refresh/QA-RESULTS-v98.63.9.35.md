# QA results — v98.63.9.35

## Video-driven keypad correction
- Replaced the fixed viewport-width dock with an app-container-relative dock.
- Rebuilt the dock as a flex column and its keypad as a stretch-filled 4x4 CSS grid.
- Removed the square aspect-ratio constraint from tool keypad cells; the tall equals key remains two rows high.
- Added short-height and landscape rules and aligned scroll padding with the dock height token.
- Main calculator and HEX keypad markup/logic remain separate.

## Local verification
- `npm run build:web`: PASS (13 required web assets).
- `npm run test:release`: PASS (57 tests, 0 failures).
- JavaScript syntax checks: PASS.
- PostCSS parse for source and generated CSS: PASS.
- YAML parse: PASS.
- Standalone YAML mirror: byte-identical to `.github/workflows/main.yml`.
- Workflow required-file and test-entrypoint checks: PASS.
- Source/generated `www` parity: PASS.
- ZIP integrity and extracted-project rerun: PASS.

## Not claimed
GitHub-hosted Actions execution, Gradle/APK compilation on GitHub, and physical Android/WebView visual validation have not been run here. The pasted prior Actions excerpt showed no explicit failed step; use the new run's first red step/log if a hosted failure remains.
