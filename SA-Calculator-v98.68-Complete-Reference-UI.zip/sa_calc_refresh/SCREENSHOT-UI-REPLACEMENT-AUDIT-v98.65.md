# Screenshot UI replacement audit — v98.65

## Reference basis
Ten supplied Android screenshots show Salary, Tip, SIP, Currency, Discount, Percentage, Unit, Age (including date picker) and BMI screens. The shared design is pale grey canvas, white rounded cards, coral-red active controls, pale pink icon tiles, muted inactive selectors, large numeric inputs and a docked 4-column keypad.

## Replaced
The prior v98.64 screenshot-specific CSS appended to the 931 KB legacy stylesheet has been removed. A separate canonical stylesheet `assets/css/tool-reference-ui.css` now owns the screenshot-reference appearance and is loaded after the base application stylesheet. This makes the new tool layer explicit and prevents the previous coral patch from remaining buried in the legacy CSS file.

## Coverage
GST, Loan, Saving, Salary, Tip, SIP, Currency Converter, Discount, Percentage, Unit Converter, Age and BMI are all included in the same reference theme. BMI retains kg/lbs and cm/in conversion controls. Age retains the native date input and existing impossible/future date validation. Unit categories remain horizontally scrollable. Currency source/target selectors and rate freshness note remain separate.

## Behaviour preservation
No calculation IDs or keypad data attributes were renamed. Existing calculator functions and event handlers remain the calculation source of truth. The new CSS is presentation-only. Android web bundle generation and service-worker precache both require the new stylesheet.

## CI safeguards
Workflow source preflight uses the actual checked-in release test files, verifies the extra stylesheet, verifies generated CSS byte identity and runs the screenshot-reference regression test.

## Verification limits
Automated source tests and build checks cannot certify pixel-perfect rendering across every Android WebView, native date-picker skin, ad SDK, or physical device. Hosted GitHub Actions APK build and device installation/performance tests are still required.
