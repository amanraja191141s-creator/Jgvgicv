# Release verification — v98.65

## Source identity
- Package: `sa-calculator`
- Version: `1.98.79-v98.65`
- Android version code: `1098086`
- Capacitor web directory: `www`

## Local checks
- JavaScript syntax: passed for app, localization, currency names, theme bootstrap, service worker and build scripts.
- Android web bundle: passed; all 14 required source assets verified and copied.
- Release regression suite: 70 tests passed, 0 failed.
- Dedicated screenshot-reference UI tests: passed.
- Workflow YAML parse: passed.
- Workflow mirror: byte-identical.
- Source and generated `app.css` / `tool-reference-ui.css`: byte-identical.
- ZIP integrity: checked after packaging.

## Release scope
- The 12 requested tool screens use the supplied coral/light UI system.
- The former v98.64 screenshot override was removed from the end of `app.css`; the new canonical tool UI lives in `assets/css/tool-reference-ui.css`.
- The new stylesheet is included in the Android web build and service-worker precache.
- Existing calculation IDs and keypad event wiring are retained.

## Not certified locally
A hosted GitHub Actions run must still complete Android SDK setup, Capacitor Android sync, Gradle debug APK compilation, APK metadata verification and artifact upload. Physical Android device installation, vendor-native date-picker appearance, touch latency and real-world performance remain to be tested. No guarantee of zero bugs or zero lag is claimed without those checks.
