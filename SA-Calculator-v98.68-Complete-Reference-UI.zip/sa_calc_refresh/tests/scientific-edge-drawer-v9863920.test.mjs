import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('scientific keypad is a right-to-left overlay aligned to the normal keypad band', () => {
  assert.match(html, /id="screen-calc"[\s\S]*?<section class="scientific-screen scientific-drawer" id="screen-scientific"/);
  assert.match(css, /scientific-drawer[\s\S]*?width:min\(94vw,680px\)!important/);
  assert.match(css, /top:var\(--sci-drawer-top,38%\)!important/);
  assert.match(css, /height:var\(--sci-drawer-height,58%\)!important/);
  assert.match(js, /calcScreen\.style\.setProperty\('--sci-drawer-top'/);
  assert.match(js, /calcScreen\.style\.setProperty\('--sci-drawer-height'/);
});
test('normal keypad remains full width; no split/shrink layout is applied', () => {
  assert.match(css, /#screen-calc\.scientific-overlay-open > \.main-keypad \{ width:100%!important/);
  assert.doesNotMatch(js, /classList\.add\('scientific-split-open'\)/);
  assert.doesNotMatch(js, /classList\.remove\('scientific-split-open'\)/);
});
test('drawer follows the finger continuously and settles by swipe distance or velocity', () => {
  assert.match(js, /document\.addEventListener\('pointermove', gestureMove/);
  assert.match(js, /setDrawerOffset\(offset\)/);
  assert.match(js, /start\.velocity < -0\.48/);
  assert.match(js, /start\.velocity > 0\.48/);
  assert.match(css, /\.scientific-drawer\.is-dragging[\s\S]*?transition:none!important/);
});
test('function matrix matches the supplied 4x4 video layout and has one shared calculator display', () => {
  const grid = html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0] || '';
  assert.equal((grid.match(/<button\b/g) || []).length, 16);
  for (const token of ['id="sci-shift-toggle"','data-sci-insert="sin("','data-sci-insert="cos("','data-sci-insert="tan("','data-sci-insert="ln("','data-sci-insert="log("','data-sci-insert="abs("','data-sci-insert="fact("','data-sci-insert="pi"','data-sci-insert="10^("','data-sci-insert="sqrt("','id="sci-more-toggle"']) assert.ok(grid.includes(token), token);
  assert.match(css, /grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css, /grid-template-rows:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(js, /insertScientificIntoMain\(token\)/);
});
test('right edge gesture opens, reverse swipe closes, and Escape/close button remain available', () => {
  assert.match(js, /x >= width - 36/);
  assert.match(js, /if \(event\.key !== 'Escape' \|\| !drawerOpen\) return;/);
  assert.match(js, /if \(more && !more\.hidden\)/);
  assert.match(html, /id="sci-drawer-close"/);
  assert.match(js, /setOpenState\(horizontal \? shouldOpen : start\.open\)/);
});
test('scientific panel is not a Tools destination and preserves accessibility state', () => {
  assert.doesNotMatch(js, /\{ id: 'scientific', name: 'Scientific Calculator' \}/);
  assert.doesNotMatch(html, /data-tool-screen="scientific"/);
  assert.match(js, /screen\.setAttribute\('aria-hidden', String\(!open\)\)/);
  assert.match(js, /screen\.inert = !open/);
});
test('release, PWA cache and Android workflow identity are synchronized', () => {
  assert.equal(pkg.version, '1.98.76-v98.63.9.29');
  assert.match(html, /v98\.63\.9\.29/);
  assert.match(js, /APP_VERSION = '1\.98\.76-v98\.63\.9\.29'/);
  const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.match(sw, /v9863929-scientific-key-size-video-reference/);
  assert.match(workflow, /v9863929-scientific-key-size-video-reference/);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).androidVersionCode, 1098077);
  assert.match(workflow, /android_version_code=\$\{androidVersionCode\}/);
  assert.match(workflow, /versionCode='\$\{\{ steps\.locate\.outputs\.android_version_code \}\}'/);
});
