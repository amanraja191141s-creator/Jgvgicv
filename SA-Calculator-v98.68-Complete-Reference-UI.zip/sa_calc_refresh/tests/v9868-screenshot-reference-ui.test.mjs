import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const html = readFileSync(new URL('index.html', root), 'utf8');
const css = readFileSync(new URL('assets/css/tool-reference-ui.css', root), 'utf8');
const js = readFileSync(new URL('assets/js/app.js', root), 'utf8');
const build = readFileSync(new URL('scripts/prepare-android-web.mjs', root), 'utf8');
const sw = readFileSync(new URL('service-worker.js', root), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'));
test('v98.68 uses one clean canonical screenshot-reference stylesheet',()=>{
 assert.equal(pkg.version,'1.98.82-v98.68'); assert.match(html,/assets\/css\/tool-reference-ui\.css/);
 assert.ok(html.indexOf('assets/css/tool-reference-ui.css')>html.indexOf('assets/css/app.css'));
 assert.match(css,/--tool-accent:#ff625f/); assert.match(css,/--tool-keypad-height:min\(42dvh,600px\)/);
});
test('all 12 tools share the coral card, input and docked keypad system',()=>{
 for(const id of ['salestax','loan','savings','salary','sip','tip','currencies','discount','percent','units','agecalc','bodymetrics']) assert.ok(css.includes(`#screen-${id}`),`missing ${id}`);
 assert.match(css,/border-radius:27px!important/); assert.match(css,/position:absolute!important;inset:auto 0 0 0!important/);
 assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
});
test('GST/BMI/Unit reference controls remain in markup and calculation wiring',()=>{
 for(const token of ['With GST','Without GST','Same State','Different State','data-gst-rate="5"','data-gst-rate="18"','data-bmi-weight-unit="kg"','data-bmi-weight-unit="lbs"','data-bmi-height-unit="cm"','data-bmi-height-unit="in"','data-unit-category="mass"']) assert.ok(html.includes(token),`missing ${token}`);
 assert.match(js,/function calcSalesTax\(\)/); assert.match(js,/data-gst-mode/); assert.match(js,/data-gst-place/); assert.match(js,/data-gst-rate/);
});
test('hidden unit workspace respects hidden state; theme variables remain connected',()=>{
 assert.match(css,/#screen-units #unit-converter-workspace\[hidden\]\{display:none!important/);
 assert.match(css,/--tool-bg:var\(--app-bg/); assert.match(css,/--tool-card:var\(--surface-bg/);
});
test('Android bundle builder and service worker include the canonical stylesheet',()=>{
 assert.match(build,/assets\/css\/tool-reference-ui\.css/); assert.match(sw,/assets\/css\/tool-reference-ui\.css/);
});
