import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const html = readFileSync(new URL('index.html', root), 'utf8');
const css = readFileSync(new URL('assets/css/tool-reference-ui.css', root), 'utf8');
const js = readFileSync(new URL('assets/js/app.js', root), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'));
const tools = ['salestax','loan','savings','salary','tip','sip','currencies','discount','percent','units','agecalc','bodymetrics'];
test('v98.68 release identity and all 12 tool screens are present', () => {
  assert.equal(pkg.version, '1.98.82-v98.68'); assert.equal(pkg.androidVersionCode, 1098089);
  for (const id of tools) assert.match(html, new RegExp(`id="screen-${id}"`));
});
test('every tool screen has one flexible scroll workspace above the shared keypad', () => {
  for (const id of tools) {
    assert.ok(css.includes(`#screen-${id}`), `missing canonical layout for ${id}`);
    assert.match(css, /flex:1 1 0!important/);
    assert.match(css, /overflow-y:auto!important/);
    assert.match(css, /padding:14px var\(--tool-gutter\) calc\(var\(--tool-keypad-height\)/);
  }
  assert.equal((html.match(/id="tool-keypad-dock"/g)||[]).length,1);
  assert.match(css, /#tool-keypad-dock\s*\{[\s\S]*?position:absolute!important;inset:auto 0 0 0!important/);
});
test('reference keypad uses the tall four-row layout and tall equals key', () => {
  assert.match(html,/data-tool-key="7"/); assert.match(html,/data-tool-key="CLR"/);
  assert.match(html,/data-tool-key="DEL"/); assert.match(html,/data-tool-key="EQUAL"/);
  assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
  assert.match(css,/grid-row:3 \/ span 2!important/);
  assert.match(css,/--tool-keypad-height:min\(42dvh,600px\)/);
});
test('result reveal calculates without dismissing the keypad', () => {
  const branch=js.slice(js.indexOf("if (key === 'EQUAL')"),js.indexOf("} else if (key === 'CLR'",js.indexOf("if (key === 'EQUAL')")));
  assert.match(branch,/recalculateCurrentScreen\(\)/); assert.match(branch,/revealToolResultsAboveKeypad\(\)/);
  assert.doesNotMatch(branch,/closeToolKeypad\(\)/);
});
test('unit category chooser stays visible as a horizontal scroll row while hidden workspace is truly hidden', () => {
  assert.match(css,/#screen-units \.unit-category-grid\{display:flex!important;flex-wrap:nowrap!important/);
  assert.match(css,/#screen-units #unit-converter-workspace\[hidden\]\{display:none!important/);
});
test('GST, BMI and responsive fallbacks retain the screenshot geometry', () => {
  assert.match(css,/#screen-salestax \.gst-reference-card\{min-height:176px!important/);
  assert.match(css,/#screen-bodymetrics \.bmi-reference-field-card\{[^}]*min-height:176px!important/);
  assert.match(css,/@media\(max-width:380px\)/); assert.match(css,/@media\(max-height:620px\)/);
  assert.match(css,/@media\(orientation:landscape\) and \(max-height:500px\)/);
});
