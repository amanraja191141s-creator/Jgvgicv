import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const html = readFileSync(new URL('index.html', root), 'utf8');
const js = readFileSync(new URL('assets/js/app.js', root), 'utf8');
const css = readFileSync(new URL('assets/css/app.css', root), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'));

test('release identity and Android code are incremented together', () => {
  assert.equal(pkg.version, '1.98.78-v98.63.9.34');
  assert.equal(pkg.androidVersionCode, 1098082);
  assert.match(html, /1\.98\.78-v98\.63\.9\.34/);
  assert.match(js, /const APP_VERSION = '1\.98\.78-v98\.63\.9\.34'/);
});
test('only one shared numeric tool keypad exists; legacy modal markup is absent', () => {
  assert.equal((html.match(/id="tool-keypad-dock"/g) || []).length, 1);
  assert.doesNotMatch(html, /popup-keypad-overlay|popup-keypad-header|popup-input-preview|popup-val-display/);
  assert.match(html, /class="main-keypad"/);
  assert.match(html, /hex-dock-keypad/);
});
test('legacy popup keypad CSS cascade is removed, not hidden by another override', () => {
  const occurrences = (css.match(/#tool-keypad-dock\s*\{/g) || []).length;
  assert.equal(occurrences, 1, 'one authoritative dock base rule remains');
  assert.doesNotMatch(css, /popup-keypad|popup-input-preview|popup-preview|popup-close-btn/);
});
test('keypad panel and grid fill the complete width and all key cells stretch', () => {
  assert.match(css, /width:\s*100vw !important; max-width:\s*none !important/);
  assert.match(css, /width:\s*100% !important; height:\s*100% !important; min-width:\s*0 !important; min-height:\s*0 !important/);
  assert.match(css, /justify-items:\s*stretch !important; align-items:\s*stretch !important/);
  assert.match(css, /width:\s*100% !important; height:\s*100% !important; min-width:\s*0 !important; min-height:\s*0 !important;\s*max-width:\s*none !important/);
  assert.doesNotMatch(css, /width:min\(100%,17dvh\)/);
});
test('scroll space is measured from the same keypad height token', () => {
  assert.match(css, /--tool-keypad-height: min\(46dvh, 420px\)/);
  assert.match(css, /padding-bottom:\s*calc\(var\(--tool-keypad-height\) \+ 18px/);
  assert.match(js, /const keypadTop = sheet\.getBoundingClientRect\(\)\.top/);
});
test('result cards from visible tool tabs are revealed above the actual dock', () => {
  assert.match(js, /const results = Array\.from\(screen\.querySelectorAll/);
  assert.match(js, /getBoundingClientRect\(\)\.top - 16/);
  assert.match(js, /Math\.max\(\.\.\.results\.map/);
  assert.doesNotMatch(js, /const safeBottom = window\.innerHeight/);
});
test('equals keeps the keypad open and calculates without dismissing the dock', () => {
  const branch = js.match(/if \(key === 'EQUAL'\) \{([\s\S]*?)\n  \} else if \(key === 'CLR'\)/)?.[1] || '';
  assert.match(branch, /recalculateCurrentScreen\(\)/);
  assert.match(branch, /revealToolResultsAboveKeypad\(\)/);
  assert.doesNotMatch(branch, /closePopupKeypad/);
});
