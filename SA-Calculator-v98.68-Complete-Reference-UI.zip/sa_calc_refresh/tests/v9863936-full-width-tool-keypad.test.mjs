import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const root=new URL('../',import.meta.url);
const html=readFileSync(new URL('index.html',root),'utf8');
const js=readFileSync(new URL('assets/js/app.js',root),'utf8');
const css=readFileSync(new URL('assets/css/tool-reference-ui.css',root),'utf8');
const pkg=JSON.parse(readFileSync(new URL('package.json',root),'utf8'));
test('v98.68 release identity and shared keypad structure are current',()=>{
 assert.equal(pkg.version,'1.98.82-v98.68');assert.equal(pkg.androidVersionCode,1098089);
 assert.match(html,/1\.98\.82-v98\.68/);assert.match(js,/const APP_VERSION = '1\.98\.82-v98\.68'/);
 assert.equal((html.match(/id="tool-keypad-dock"/g)||[]).length,1);
});
test('single shared keypad has full-width grid and tall equals action',()=>{
 assert.match(css,/position:absolute!important;inset:auto 0 0 0!important/);
 assert.match(css,/grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/);
 assert.match(css,/grid-row:3 \/ span 2!important/);
});
test('keypad remains open after equals and result reveal is dock-aware',()=>{
 const branch=js.match(/if \(key === 'EQUAL'\) \{([\s\S]*?)\n  \} else if \(key === 'CLR'\)/)?.[1]||'';
 assert.match(branch,/recalculateCurrentScreen\(\)/);assert.match(branch,/revealToolResultsAboveKeypad\(\)/);assert.doesNotMatch(branch,/closeToolKeypad/);
 assert.match(js,/const keypadTop = sheet\.getBoundingClientRect\(\)\.top/);
});
