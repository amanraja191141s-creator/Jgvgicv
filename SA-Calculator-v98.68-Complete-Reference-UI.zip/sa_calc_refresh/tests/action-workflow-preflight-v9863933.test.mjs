import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const workflow = readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8'));
test('workflow release identity matches current package version', () => {
  assert.equal(pkg.version, '1.98.78-v98.63.9.33');
  assert.match(workflow, /SA_EXPECTED_VERSION: '1\.98\.78-v98\.63\.9\.33'/);
  assert.match(workflow, /v98\.63\.9\.33 release regression suite/);
  assert.doesNotMatch(workflow, /v98\.63\.9\.31/);
});
test('workflow provisions Android SDK before verifying tools', () => {
  assert.match(workflow, /uses: android-actions\/setup-android@v3/);
  assert.match(workflow, /platforms;android-35/);
  assert.match(workflow, /build-tools;35\.0\.0/);
  assert.match(workflow, /platform-tools/);
  assert.match(workflow, /platform-tools\/adb/);
  assert.match(workflow, /build-tools\/35\.0\.0\/aapt/);
});
test('workflow derives regression file checks from the actual npm release script', () => {
  assert.match(workflow, /test:release/);
  assert.match(workflow, /Release test entry point/);
  assert.doesNotMatch(workflow, /CHANGELOG-v98\.63\.9\.31\.md|MICRO-LEVEL-AUDIT-v98\.63\.9\.31\.md/);
});
test('npm install cannot mutate the source project with an incidental lockfile', () => {
  assert.match(workflow, /npm install --no-package-lock --no-audit --no-fund/);
});
test('workflow checks APK SDK tools with safe unset-variable handling', () => {
  assert.match(workflow, /SDK="\$\{ANDROID_HOME:-\$\{ANDROID_SDK_ROOT:-\}\}"/);
  assert.match(workflow, /dump badging/);
});
